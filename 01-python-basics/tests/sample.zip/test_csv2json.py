from csv2json import validate

def test_validate_pass():
    rows = [{"name": "Alice", "age": "30"}]
    result = validate(rows, ["name", "age"])
    assert result == rows

def test_validate_missing():
    rows = [{"name": "Alice"}]
    result = validate(rows, ["name", "age"])
    assert result == rows  # tetap mengembalikan rows meski ada yang hilang