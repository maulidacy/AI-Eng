import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from CLI_Sederhana.csv2json import validate

def test_validate_pass():
    rows = [{"name": "Alice", "age": "30"}]
    result = validate(rows, ["name", "age"])
    assert result == rows

def test_validate_missing():
    rows = [{"name": "Alice"}]
    result = validate(rows, ["name", "age"])
    assert result == rows  # tetap mengembalikan rows meski ada yang hilang

if __name__ == "__main__":
    test_validate_pass()
    test_validate_missing()
    print("All tests passed!")
